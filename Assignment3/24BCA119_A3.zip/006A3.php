<?php
    $data = array(
        array(1, 2, 3),
        array(4, 5, 6)
    );
    print_r($data);
?>
