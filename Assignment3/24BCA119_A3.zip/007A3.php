<?php
    $array = array(1, 2, 2, 3, 4, 4, 5);
    $result = array_unique($array);
    print_r($result);
?>
