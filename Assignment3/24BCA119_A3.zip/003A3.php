<?php
    $student = array(
        "name" => "Dhruv",
        "age" => 20,
        "course" => "BCA"
    );
    print_r($student);
?>
