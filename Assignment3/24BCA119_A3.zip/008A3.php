<?php
    $array = array(10, 20, 30, 40);
    echo array_sum($array);
?>
