<?php
    $animals = array("Dog", "Cat", "Elephant", "Tiger");

    if (in_array("Cat", $animals)) {
        echo "Cat found";
    } else {
        echo "Cat not found";
    }
?>
