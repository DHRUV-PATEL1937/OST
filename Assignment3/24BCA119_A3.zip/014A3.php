<?php
    $array = array(10, 45, 23, 89, 5);

    echo "Max = " . max($array) . "<br>";
    echo "Min = " . min($array);
?>
