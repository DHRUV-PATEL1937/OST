<?php
    $numbers = array(45, 12, 78, 34, 89);
    sort($numbers);
    print_r($numbers);
?>
