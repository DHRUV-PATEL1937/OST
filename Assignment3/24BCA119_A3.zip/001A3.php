<?php
    $fruits = array("Apple", "Banana", "Cherry", "Date");
    print_r($fruits);
?>
