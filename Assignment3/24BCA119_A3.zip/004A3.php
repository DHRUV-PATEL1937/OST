<?php
    $array1 = array("Red", "Blue", "Green");
    $array2 = array("Yellow", "Purple", "Orange");
    $result = array_merge($array1, $array2);
    print_r($result);
?>
